<?php

    include 'hal-admin/koneksi.php';

?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <link rel="stylesheet" href="hal-admin/css/tampilan.css">

    <title>Online Shop</title>

    <style>
    body {
        background-color: <?php echo $warna;
        ?>;
    }
    </style>
</head>

<body>

    <!-- As a link -->
    <nav class="navbar navbar-dark bg-dark">
        <a class="navbar-brand" href="index.php">
            <img src="hal-admin/img/django.png" alt="logo web" width='150'><b>Online Shop</b>
        </a>
        <form class="form-inline" action="?hal=produk-keyword" method="post">
            <input id="sandi" name="sandi" class="form-control mr-sm-2" type="search" placeholder="Kata Kunci" aria-label="Search">
            <button class="btn btn-primary my-2 my-sm-0" type="submit">Cari</button>
        </form>
    </nav>


    <div class="container-fluid badan-depan">

        <div class="row">
            <div class="col-2">
                <?php
                    include 'fungsional/menu-kiri.php';
                ?>
            </div>

            <div class="col-10">
                <?php
                    include 'fungsional/panggil-halaman.php';
                ?>
            </div>
        </div>

    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    
    
    <script>
    $(document).ready(function () 
    {
        $("#sandi").autocomplete(
            {
                source:'fungsional/rekomen-produk.php',
                select: function(event, ui)
                {
                    event.prevenDefault();
                    $("#sandi").val("ui.item.nama_produk");
                }
            }
        );

    });
    </script>

</body>

</html>