<?php

    $idp = $_GET['idp'];

    $sql = "SELECT * FROM `produk`
    INNER JOIN kategori ON produk.id_kategori = kategori.id_kategori
    INNER JOIN user ON produk.id_user = user.id_user 
    WHERE produk.id_produk = '$idp'
    ORDER BY produk.id_produk DESC
";

    $que = mysqli_query($sambungan, $sql);
    $cek = mysqli_num_rows($que);


    if($cek>0)
    {
        while ($a = mysqli_fetch_array($que)) 
        {
            $id_pro     = $a["id_produk"];
            $name_pro   = $a["nama_produk"];
            $cat_pro    = $a["nama_kategori"];
            $harga      = $a["harga"];
            $foto       = $a["foto"];
            $username   = $a['username'];
            $deskrip    = $a['deskripsi'];


            $hargarp = "Rp.".number_format($harga,0,".",".")."."."-";

            if ($foto==null) 
            {
                $gambar = "hal-admin/img/no.png";
            } else {
                $gambar = "hal-admin/produk-img/$foto.jpg";
            }
            

            echo
            "
                <h3>$name_pro</h3>

                <p align='right'>
                    <b>$cat_pro</b>, diupload oleh $username
                </p>

                <center>
                    <img src='$gambar' alt='$name_pro' width='60%' height='270'>
                </center>

                <p>
                    $deskrip
                </p>
            ";
        }
    }
    else{
        echo
        "
            <h5>Data Tidak Tersedia...</h5>
        ";
    }
?>