<?php

    //fungsi file ini untuk
    //menerima parameter ?hal yang kita pilih di navigasi kiri index.php
    //error_reporting(0);
    $halaman = $_GET['hal'];

    if (empty($halaman)) //jika halaman kosong
    {
        # biasanya web dalam kondisi pertama kali dibuka
        include 'home.php';
    } else // jika sudah pilih menu
    {
        include "$halaman".'.php';
    }

?>