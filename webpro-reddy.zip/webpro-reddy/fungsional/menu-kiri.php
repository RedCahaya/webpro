<ul class="nav flex-column">
  
  <?php

        $sql = "SELECT * FROM kategori";
        $que = mysqli_query($sambungan, $sql);

        $no = 1;
        while ($a = mysqli_fetch_array($que)) 
        {
            $id_cat = $a["id_kategori"];
            $name_cat = $a["nama_kategori"];

            echo
            "
            <li class='nav-item'>
                <a class='nav-link active' href='?hal=detail-kategori&idc=$id_cat'>$name_cat</a>
            </li>   
            ";
            $no++;
        }

    ?>
</ul>