<h2>Tambah Kategori</h2>

<form action="?hal=kategori-simpan" method="post">

    <p>
        Nama Kategori: <br>
        <input type="text" name="nama" required>
    </p>

    <p>
    <input type="submit" value="SIMPAN">
    </p>

</form>