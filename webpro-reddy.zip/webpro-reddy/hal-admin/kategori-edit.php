<h2>Edit Kategori</h2>

<?php

include 'koneksi.php';

$idk = $_GET['aidi'];

$sql = "SELECT * FROM kategori WHERE id_kategori='$idk'";
$que = mysqli_query($sambungan, $sql);

while ($a = mysqli_fetch_array($que)) 
{
    //$id_cat = $a["id_kategori"];
    $name_cat = $a["nama_kategori"];
}

?>

<form action="?hal=kategori-ubah" method="post">

<input type="hidden" name="idk" value="<?php echo "$idk";?>">

    <p>
        Nama Kategori: <br>
        <input type="text" name="nama" required value="<?php echo "$name_cat";?>">
    </p>

    <p>
        <input type="submit" value="SIMPAN">
    </p>

</form>