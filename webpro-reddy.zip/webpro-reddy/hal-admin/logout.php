<?php
    session_start();

    //menghapus
    //session_unset($_SESSION['user_id']);
    //session_unset($_SESSION['user_status']);
    session_destroy();

    header('location:index.php');
?>