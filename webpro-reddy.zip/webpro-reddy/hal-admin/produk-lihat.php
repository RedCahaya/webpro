<?php

        include 'koneksi.php';

        //member hanya bsa melihat produknya sendiri

        $idp = $_GET['aidi'];

        if ($status=='Member') 
        {
            $sql = "SELECT * FROM `produk`
                    INNER JOIN kategori ON produk.id_kategori = kategori.id_kategori
                    INNER JOIN user ON produk.id_user = user.id_user
                    WHERE produk.id_user = $id_user AND produk.id_produk = '$idp' 
                    ORDER BY produk.id_produk DESC
                    ";
        } 
        else //admin, manager bisa lihat semua
        {
            $sql = "SELECT * FROM `produk`
                    INNER JOIN kategori ON produk.id_kategori = kategori.id_kategori
                    INNER JOIN user ON produk.id_user = user.id_user 
                    WHERE produk.id_produk = '$idp'
                    ORDER BY produk.id_produk DESC
                    ";
        }
        

        $que = mysqli_query($sambungan, $sql);

        $no = 1;
        while ($a = mysqli_fetch_array($que)) 
        {
            $id_pro     = $a["id_produk"];
            $name_pro   = $a["nama_produk"];
            $cat_pro    = $a["nama_kategori"];
            $harga      = $a["harga"];
            $foto       = $a["foto"];
            $username   = $a['username'];
            $desk       = $a['deskripsi'];

            if ($foto==null) 
            {
                $gambar = "<img src='img/no.png' width='60%' height='300'>";
            } else {
                $gambar = "<img src='produk-img/$foto.jpg' width='60%' height='300'>";
            }
            

            echo
            "
                <h2>$name_pro</h2>
                <p align='justify'>$cat_pro</p><br>
                
                <p>$desk</p>

                <center>$gambar</center>

                <a href=?hal=produk-data>Kembali</a>
            ";
            $no++;
        }

    ?>