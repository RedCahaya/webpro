<?php

    include 'koneksi.php';

    $idk = $_GET['aidi'];

    $sql = "DELETE FROM kategori WHERE id_kategori=$idk";
    $que = mysqli_query($sambungan, $sql);

    if ($que) 
    {
        echo
        "
            <script>
                alert('Data Telah Dihapus');
                window.location = '?hal=kategori-data';
            </script>
        ";
    } else 
    {
        echo
        "
            <script>
                alert('Data Gagal Dihapus');
                window.location = '?hal=kategori-data';
            </script>
        ";
    }
?>