<h4>Selamat Datang, <span style='color:crimson'><?php echo "$namauser"?></span></h4>

<div class="row">
    <div class="col-sm">
        <center>
            <img src="img/django.png" alt="logo web" width="50%"">
        </center>
    </div>

    <div class="col-sm">
        <p>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Perferendis dignissimos minima fugit, dolores blanditiis quaerat animi, aspernatur repellendus fuga est rem voluptas quidem odio atque similique provident numquam earum porro.
        </p>

        <p>
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Perferendis dignissimos minima fugit, dolores blanditiis quaerat animi, aspernatur repellendus fuga est rem voluptas quidem odio atque similique provident numquam earum porro.
        </p>
    </div>    
</div>