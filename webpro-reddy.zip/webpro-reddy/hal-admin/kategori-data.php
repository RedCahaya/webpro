<h2>Data Kategori</h2>

<a href="?hal=kategori-tambah">Tambah Baru</a>
<table border="1" width="350">
    <tr>
        <th>No.</th>
        <th>Nama Kategori</th>
        <th>Aksi</th>
    </tr>

    <?php

        include 'koneksi.php';

        $sql = "SELECT * FROM kategori";
        $que = mysqli_query($sambungan, $sql);

        $no = 1;
        while ($a = mysqli_fetch_array($que)) 
        {
            $id_cat = $a["id_kategori"];
            $name_cat = $a["nama_kategori"];

            echo
            "
                <tr>
                    <td align='center'>$no</td>
                    <td align='center'>$name_cat</td>
                    <td align='center'>
                        <a href='?hal=kategori-edit&aidi=$id_cat'>Edit</a>
                        <a href='?hal=kategori-hapus&aidi=$id_cat'>Hapus</a>
                    </td>
                </tr>
            ";
            $no++;
        }

    ?>
</table>