<h2>Tambah Produk</h2>
                                        <!--jika ada file tambahkan enctype="multipart/form-data"-->
<form class="form-produk" action="?hal=produk-simpan" method="post" enctype="multipart/form-data">

    <p>
        Nama Produk: <br>
        <input type="text" name="nama" required>
    </p>

    <p>
        Kategori: <br>
        <select name="kat" required>
            <option value="">-Pilih Kategori-</option>
            <?php
                include 'koneksi.php';

                $sql = "SELECT * FROM kategori";
                $que = mysqli_query($sambungan, $sql);
        
                while ($a = mysqli_fetch_array($que)) 
                {
                    $id_cat = $a["id_kategori"];
                    $name_cat = $a["nama_kategori"];
        
                    echo
                    "
                        <option value='$id_cat'>$name_cat</option>
                    ";
                }
            ?>
        </select>
    </p>

    <p>
        Deskripsi: <br>
        <textarea name="deskripsi"cols="30" rows="10"></textarea>
    </p>

    <p>
        Harga: <br>
        <input type="text" name="harga" required>
    </p>

    <p>
        Foto Produk: <br>
        <input type="file" name="foto">
    </p>

    <p>
    <input type="submit" value="SIMPAN">
    </p>

</form>