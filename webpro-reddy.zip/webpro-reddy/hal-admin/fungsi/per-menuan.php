<?php
    //$status --> didapatkan di file index.php --> deklarasi sessionnya
    if ($status == 'Manager') //usahakan sesuai db
    {
        echo
        "
        <h6>Menu $status</h6>

        <nav class='nav flex-column'>
            <li class='nav-item'>
                <!--?hal untuk di proses di panggil-halaman.php-->
                <a class='nav-link active' href='?hal=home'>Home</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link' href='?hal=kategori-data' tabindex='-1' aria-disabled='true'>Kategori</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link' href='?hal=produk-data' tabindex='-2' aria-disabled='true'>Produk</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link' href='logout.php' tabindex='-3' aria-disabled='true'>Logout</a>
            </li>
        </nav>        
        ";
    } 
    else if ($status== 'Admin')
    {
        echo
        "
        <h6>Menu $status</h6>

        <nav class='nav flex-column'>
            <li class='nav-item'>
                <!--?hal untuk di proses di panggil-halaman.php-->
                <a class='nav-link active' href='?hal=home'>Home</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link' href='?hal=kategori-data' tabindex='-1' aria-disabled='true'>Kategori</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link' href='?hal=produk-data' tabindex='-2' aria-disabled='true'>Produk</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link' href='#' tabindex='-2' aria-disabled='true'>Data User</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link' href='logout.php' tabindex='-3' aria-disabled='true'>Logout</a>
            </li>
        </nav>
        ";
    }

    else 
    {
        echo
        "
        <h6>Menu $status</h6>

        <nav class='nav flex-column'>
            <li class='nav-item'>
                <!--?hal untuk di proses di panggil-halaman.php-->
                <a class='nav-link active' href='?hal=home'>Home</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link' href='?hal=kategori-data' tabindex='-1' aria-disabled='true'>Kategori</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link' href='?hal=produk-data' tabindex='-2' aria-disabled='true'>Produk</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link' href='#' tabindex='-2' aria-disabled='true'>Profil</a>
            </li>
            <li class='nav-item'>
                <a class='nav-link' href='logout.php' tabindex='-3' aria-disabled='true'>Logout</a>
            </li>
        </nav>
        ";
    }
    
?>