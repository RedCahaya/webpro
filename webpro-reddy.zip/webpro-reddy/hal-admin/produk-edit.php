<h2>Produk Edit</h2>

<?php

include 'koneksi.php';

$idp = $_GET['aidi'];

if ($status=='Member') 
{
    $sql = "SELECT * FROM `produk`
            INNER JOIN kategori ON produk.id_kategori = kategori.id_kategori
            INNER JOIN user ON produk.id_user = user.id_user
            WHERE produk.id_user = $id_user AND produk.id_produk = '$idp' 
            ORDER BY produk.id_produk DESC
            ";
} 
else //admin, manager bisa lihat semua
{
    $sql = "SELECT * FROM `produk`
            INNER JOIN kategori ON produk.id_kategori = kategori.id_kategori
            INNER JOIN user ON produk.id_user = user.id_user 
            WHERE produk.id_produk = '$idp'
            ORDER BY produk.id_produk DESC
            ";
}

$que = mysqli_query($sambungan, $sql);

while ($a = mysqli_fetch_array($que)) 
{
    $id_pro = $a["id_produk"];
    $name_pro = $a["nama_produk"];
    $cat_pro = $a["nama_kategori"];
    $harga = $a["harga"];
    $idkat = $a["id_kategori"];
    $deskrip = $a["deskripsi"];
    $foto       = $a["foto"];

    if ($foto==null) 
    {
        $gambar = "<img src='img/no.png' width='100' height='100'>";
    } else {
        $gambar = "<img src='produk-img/$foto.jpg' width='100' height='100'>";
    }
}

?>

<form class="form-produk" action="?hal=produk-ubah" method="post" enctype="multipart/form-data">

<input type="hidden" name="aidi" required value="<?php echo"$id_pro"?>">    
    <p>
        Nama Produk: <br>
        <input type="text" name="nama" required value="<?php echo"$name_pro"?>">
    </p>

    <p>
        Kategori: <br>
        <select name="kat" required>
            <?php
                echo
                "
                    <option value='$idkat'>$cat_pro</option>
                ";

                $sql = "SELECT * FROM kategori";
                $que = mysqli_query($sambungan, $sql);
        
                while ($a = mysqli_fetch_array($que)) 
                {
                    $id_cat = $a["id_kategori"];
                    $name_cat = $a["nama_kategori"];
                    
                    echo
                "
                    <option value='$id_cat'>$name_cat</option>
                ";
                    
                }
            ?>
        </select>
    </p>

    <p>
        Deskripsi: <br>
        <textarea name="deskripsi"cols="30" rows="10"><?php echo "$deskrip"?></textarea>
    </p>

    <p>
        Harga: <br>
        <input type="text" name="harga" required value="<?php echo "$harga"?>">
    </p>

    <p>
        Foto Produk: <br>
        <input type="file" name="foto">
    </p>
    
    <p>
        <?php echo "$gambar";?>
    </p>

    <p>
    <input type="submit" value="SIMPAN">
    </p>

</form>