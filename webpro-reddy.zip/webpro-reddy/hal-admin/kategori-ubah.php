<?php

    include 'koneksi.php';

    $idk = $_POST['idk'];
    $nama = $_POST['nama'];

    $sql = "UPDATE `kategori` SET `nama_kategori`='$nama' WHERE `id_kategori`='$idk'";
    $que = mysqli_query($sambungan, $sql);

    if ($que) 
    {
        echo
        "
            <script>
                alert('Data Telah Diubah');
                window.location = '?hal=kategori-data';
            </script>
        ";
    } else 
    {
        echo
        "
            <script>
                alert('Data Gagal Diubah');
                window.location = '?hal=kategori-edit&aidi=$idk';
            </script>
        ";
    }
    

?>