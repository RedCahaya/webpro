<?php

    include 'koneksi.php';

    $nama = $_POST['nama'];

    $sql = "INSERT INTO `kategori`(`id_kategori`, `nama_kategori`) VALUES (NULL,'$nama')";
    $que = mysqli_query($sambungan, $sql);

    if ($que) 
    {
        echo
        "
            <script>
                alert('Data Telah Disimpan');
                window.location = '?hal=kategori-data';
            </script>
        ";
    } else 
    {
        echo
        "
            <script>
                alert('Data Gagal Disimpan');
                window.location = '?hal=kategori-tambah';
            </script>
        ";
    }
    

?>