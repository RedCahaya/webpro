<?php

    include 'koneksi.php';

    $nama = $_POST['nama'];
    $cat = $_POST['kat'];
    $desc = $_POST['deskripsi'];
    $price = $_POST['harga'];
    
    //Foto
    $namafoto = $_FILES['foto']['name'];
    $lokasinya = $_FILES['foto']['tmp_name'];

    //acak nama foto
    $tglup      = date("d-m-yh:i:s");
    $tglub      = md5($tglup);
    $namabaru   = "Foto".$tglub;

    //session buar manampilkan siapa yang upload foto produk
    //karena udah di definisikan di index, jadi gak perlu session_start lagi

    //kondisi upload foto

    if (empty($namafoto)) //jika belum upload
    {
        $sql = "INSERT INTO produk VALUES (null,'$nama','$cat','$desc','$price','$id_user', null )";
    } 
    else //jika udah upload
    {
        //memasukkan ke folder
        move_uploaded_file($lokasinya, "produk-img/$namabaru.jpg");
        $sql = "INSERT INTO produk VALUES (null,'$nama','$cat','$desc','$price','$id_user', '$namabaru' )";
    }
    

    $que = mysqli_query($sambungan, $sql);

    if ($que) 
    {
        echo
        "
            <script>
                alert('Data Telah Disimpan');
                window.location = '?hal=produk-data';
            </script>
        ";
    } else 
    {
        echo
        "
            <script>
                alert('Data Gagal Disimpan');
                window.location = '?hal=produk-tambah';
            </script>
        ";
    }
    

?>