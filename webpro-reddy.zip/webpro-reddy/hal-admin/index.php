<?php

    //pengecekan session
    session_start();

    if (empty($_SESSION['user_id'])) 
    {
        header('location:form-login.php');
    }

    $id_user = $_SESSION['user_id'];
    $status = $_SESSION['user_status'];

    if ($status=='Manager') 
    {
        $warna = 'brown';
    }


    include 'koneksi.php';
    $sql = mysqli_query($sambungan, "SELECT *FROM user WHERE id_user='$id_user'");
    while ($a = mysqli_fetch_array($sql)) 
    {
        $namauser = $a['username']; //set nama usernya
    }

?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="css/tampilan.css">

    <title>Admin</title>

    <style>
        body {
            background-color:<?php echo $warna;?>;
        }
    </style>
</head>

<body>

    <!-- As a link -->
    <nav class="navbar navbar-dark bg-dark">
        <a class="navbar-brand" href="index.php">
            <img src="img/django.png" alt="logo web" width='150'><b>Online Shop</b>
        </a>
    </nav>


    <div class="container badan-utama">

        <div class="row">
            <div class="col-2">
                <?php
                    include 'fungsi/per-menuan.php';
                ?>
            </div>

            <div class="col-10">
                <?php
                    include 'fungsi/panggil-halaman.php';
                ?>
            </div>
        </div>

    </div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous">
    </script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous">
    </script>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

    <script>
        $(document).ready(function()
        {
            $('#tabelku').DataTable();
        });
    </script>
</body>

</html>