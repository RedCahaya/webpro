<h2>Data Produk</h2>

<a href="?hal=produk-tambah">Tambah Baru</a>
<a href="?hal=produk-data">Kembali</a>

<table border="1" width="500" id="tabelku">
    <thead>
        <tr>
            <th>No.</th>
            <th>Foto</th>
            <th>Nama Produk</th>
            <th>Kategori</th>
            <th>Harga</th>
            <th>Pemilik</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php

        include 'koneksi.php';

        //member hanya bsa melihat produknya sendiri

        $idkateg = $_GET['idk'];

        if ($status=='Member') 
        {
            $sql = "SELECT * FROM `produk`
                    INNER JOIN kategori ON produk.id_kategori = kategori.id_kategori
                    INNER JOIN user ON produk.id_user = user.id_user
                    WHERE produk.id_user = $id_user AND produk.id_kategori = '$idkateg'
                    ORDER BY produk.id_produk DESC";

        } 
        else //admin, manager bisa lihat semua
        {
            $sql = "SELECT * FROM `produk`
                    INNER JOIN kategori ON produk.id_kategori = kategori.id_kategori
                    INNER JOIN user ON produk.id_user = user.id_user 
                    WHERE produk.id_kategori = '$idkateg'
                    ORDER BY produk.id_produk DESC
                    ";
        }
        

        $que = mysqli_query($sambungan, $sql);

        $no = 1;
        while ($a = mysqli_fetch_array($que)) 
        {
            $id_pro     = $a["id_produk"];
            $name_pro   = $a["nama_produk"];
            $cat_pro    = $a["nama_kategori"];
            $harga      = $a["harga"];
            $foto       = $a["foto"];
            $username   = $a['username'];

            if ($foto==null) 
            {
                $gambar = "<img src='img/no.png' width='100' height='100'>";
            } else {
                $gambar = "<img src='produk-img/$foto.jpg' width='100' height='100'>";
            }
            

            echo
            "
                <tr>
                    <td align='center'>$no</td>
                    <td>
                        <center>$gambar</center>
                    </td>
                    <td align='center'>$name_pro</td>
                    <td align='center'>$cat_pro</td>
                    <td align='center'>$harga</td>
                    <td align='center'>$username</td>
                    <td align='center'>
                        <a href='?hal=produk-lihat&aidi=$id_pro'>Lihat</a>
                        <a href='?hal=produk-edit&aidi=$id_pro'>Edit</a>
                        <a href='?hal=produk-hapus&aidi=$id_pro'>Hapus</a>
                    </td>
                </tr>
            ";
            $no++;
        }

    ?>
    </tbody>

</table>


<h5 style="margin-top:50px;">Cari Berdasarkan Kategori: </h5>

<b>
    <ul>

        <?php

            include 'koneksi.php';

            $sql = "SELECT * FROM kategori";
            $que = mysqli_query($sambungan, $sql);

            while ($a = mysqli_fetch_array($que)) 
            {
                $id_cat = $a["id_kategori"];
                $name_cat = $a["nama_kategori"];

                echo
                "
                <li><a href='?hal=produk-kategori&idk=$id_cat'>$name_cat</a></li>
                ";
            }

        ?>
    </ul>
</b>