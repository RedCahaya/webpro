<?php

    $server = "localhost";
    $username = "root";
    $password = "";
    $database = "online_shop3";

    $sambungan = mysqli_connect($server, $username, $password, $database);

    if (!$sambungan) //jika $sambungan tidak bekerja 
    {
        echo
        "
            <h3>Tidak Ada Koneksi Database......</h3>
        ";
    }

?>